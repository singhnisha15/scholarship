from allauth.socialaccount.adapter import DefaultSocialAccountAdapter
from allauth.exceptions import ImmediateHttpResponse
from django.contrib import messages
from django.shortcuts import redirect
import json

from .services.academic_api import get_student_details


class ScholarshipSocialAccountAdapter(DefaultSocialAccountAdapter):

    STAFF_EMAILS = {
        "ar.sch@itbhu.ac.in",
        "office.sch@itbhu.ac.in",
        "nisha.cis@itbhu.ac.in",
    }

    def pre_social_login(self, request, sociallogin):
        """
        Called after Google successfully authenticates the user,
        but before django-allauth completes the login.

        Student access is allowed only when:
        1. Google authentication succeeds.
        2. Google email is available.
        3. Academic API returns status == 'ok'.
        4. Academic API email exactly matches Google email.

        Staff users listed in STAFF_EMAILS are allowed separately.
        """

        google_email = (
            sociallogin.user.email
            or sociallogin.account.extra_data.get("email", "")
        ).strip().lower()

        if not google_email:
            messages.error(
                request,
                "Google did not provide a valid email address."
            )
            raise ImmediateHttpResponse(
                redirect("common_login")
            )

        # -------------------------------------------------
        # STAFF LOGIN
        # -------------------------------------------------

        if google_email in self.STAFF_EMAILS:
            request.session["email"] = google_email
            request.session["user_type"] = "staff"
            request.session["home_url"] = "scholarship_dashboard"

            return

        # -------------------------------------------------
        # STUDENT LOGIN
        # -------------------------------------------------

        try:
            student_payload = get_student_details(google_email)

            if not student_payload or not student_payload.strip():
                messages.error(
                    request,
                    "Your student details could not be retrieved from "
                    "the academic server."
                )
                raise ImmediateHttpResponse(
                    redirect("common_login")
                )

            student_api_data = json.loads(student_payload)

        except Exception as exc:
            print("Academic API authentication error:", exc)

            messages.error(
                request,
                "Unable to verify your student details with the "
                "academic server. Please try again later."
            )

            raise ImmediateHttpResponse(
                redirect("common_login")
            )

        # -------------------------------------------------
        # API STATUS CHECK
        # -------------------------------------------------

        api_status = str(
            student_api_data.get("status", "")
        ).strip().lower()

        if api_status != "ok":
            print(
                "Student login rejected: API status =",
                api_status
            )

            messages.error(
                request,
                "Your student record could not be verified. "
                "Please contact the scholarship office."
            )

            raise ImmediateHttpResponse(
                redirect("common_login")
            )

        # -------------------------------------------------
        # API EMAIL CHECK
        # -------------------------------------------------

        api_email = str(
            student_api_data.get("email", "")
        ).strip().lower()

        if not api_email:
            messages.error(
                request,
                "The academic server did not return a student email."
            )

            raise ImmediateHttpResponse(
                redirect("common_login")
            )

        if api_email != google_email:
            print(
                "Student login rejected: "
                f"Google={google_email}, API={api_email}"
            )

            messages.error(
                request,
                "The Google account does not match the student "
                "record maintained by the academic server."
            )

            raise ImmediateHttpResponse(
                redirect("common_login")
            )

        # -------------------------------------------------
        # STUDENT VERIFIED
        # -------------------------------------------------

        request.session["email"] = google_email
        request.session["user_type"] = "student"

        # Keep the complete API response temporarily.
        request.session["academic_api_data"] = student_api_data

        request.session["home_url"] = "student_dashboard"

        print(
            f"Student Google login verified successfully: "
            f"{google_email}"
        )